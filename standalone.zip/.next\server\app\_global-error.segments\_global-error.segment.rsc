1:"$Sreact.fragment"
2:I[57121,[],""]
3:I[74581,[],""]
0:{"buildId":"OiktxR4g0Cg_5wjs0HWH3","rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"loading":null,"isPartial":false}
