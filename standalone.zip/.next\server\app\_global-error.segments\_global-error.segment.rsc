1:"$Sreact.fragment"
2:I[57121,[],""]
3:I[74581,[],""]
0:{"buildId":"73ANjb3lap-raR8SmFHW-","rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"loading":null,"isPartial":false}
